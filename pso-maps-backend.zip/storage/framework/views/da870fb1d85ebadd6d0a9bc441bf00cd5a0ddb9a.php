<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="flex mb-4">
        <div class="w-1/3 mx-auto">
            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                <div class="max-w-sm rounded bg-white overflow-hidden shadow-lg mt-6">
                    <div class="px-6 py-4">
                        <div class="font-bold text-xl mb-2">Total Daftar Lokasi</div>
                        <p class="text-gray-700 text-base">
                            Total daftar lokasi saat ini <?php echo e($locations->count()); ?>

                        </p>
                    </div>
                    <div class="px-6 pt-4 pb-2 mb-5">
                        <a href="<?php echo e(route('dashboard.locations.index')); ?>" class="inline-block bg-gray-200 rounded-full px-3 py-1 text-sm font-semibold text-gray-700 mr-2 mb-2">Selengkapnya</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="w-1/3 mx-auto">
            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                <div class="max-w-sm rounded bg-white overflow-hidden shadow-lg mt-6">
                    <div class="px-6 py-4">
                        <div class="font-bold text-xl mb-2">Total Daftar Gambar</div>
                        <p class="text-gray-700 text-base">
                            Total dafar gambar saat ini <?php echo e($gallery->count()); ?>

                        </p>
                    </div>
                    <div class="px-6 pt-4 pb-2 mb-5">
                        <span class="inline-block bg-gray-200 rounded-full px-3 py-1 text-sm font-semibold text-gray-700 mr-2 mb-2">Selengkapya</span>
                    </div>
                </div>
            </div>
        </div>
        <div class="w-1/3 mx-auto">
            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                <div class="max-w-sm rounded bg-white overflow-hidden shadow-lg mt-6">
                    <div class="px-6 py-4">
                        <div class="font-bold text-xl mb-2">Pengguna</div>
                        <p class="text-gray-700 text-base">
                            Pengguna terdaftar saat ini <?php echo e($users->count()); ?>

                        </p>
                    </div>
                    <div class="px-6 pt-4 pb-2 mb-5">
                        <a href="<?php echo e(route('dashboard.user.index')); ?>" class="inline-block bg-gray-200 rounded-full px-3 py-1 text-sm font-semibold text-gray-700 mr-2 mb-2">Selengkapya</a>
                    </div>
                </div>
            </div>
        </div>
    </div>


 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\pso-maps-backend\resources\views/pages/dashboard/index.blade.php ENDPATH**/ ?>